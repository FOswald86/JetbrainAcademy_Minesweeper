package minesweeper;

public class Cell {
    boolean isMine = false;
    boolean isMarked = false;
    boolean isOpened = false;

    int row;
    int col;

}